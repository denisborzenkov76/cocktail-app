package com.example.cocktailapp.ui.viewmodel

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.example.cocktailapp.data.Cocktail
import com.example.cocktailapp.data.CocktailManager

class CocktailViewModel : ViewModel() {

    val cocktails: MutableList<Cocktail> = mutableStateListOf()

    var searchQuery by mutableStateOf("")
        private set

    var selectedBase by mutableStateOf("Все")
        private set

    var filteredCocktails by mutableStateOf(emptyList<Cocktail>())
        private set

    init {
        cocktails.addAll(CocktailManager.initialCocktails)
        filterCocktails()
    }

    fun setSearchQuery(query: String) {
        searchQuery = query
        filterCocktails()
    }

    fun setSelectedBase(base: String) {
        selectedBase = base
        filterCocktails()
    }

    private fun filterCocktails() {
        var result = cocktails.toList()

        if (searchQuery.isNotBlank()) {
            result = result.filter { it.name.contains(searchQuery, ignoreCase = true) }
        }

        if (selectedBase != "Все") {
            result = result.filter { it.base == selectedBase }
        }

        filteredCocktails = result
    }

    fun getCocktailById(id: Int): Cocktail? {
        return cocktails.find { it.id == id }
    }

    fun addCocktail(cocktail: Cocktail) {
        val newCocktail = cocktail.copy(id = CocktailManager.generateNextId())
        cocktails.add(newCocktail)
        filterCocktails()
    }

    fun updateCocktail(cocktail: Cocktail) {
        val index = cocktails.indexOfFirst { it.id == cocktail.id }
        if (index != -1) {
            cocktails[index] = cocktail
            filterCocktails()
        }
    }

    fun deleteCocktail(id: Int) {
        cocktails.removeAll { it.id == id }
        filterCocktails()
    }

    fun updateIngredientCheck(cocktailId: Int, ingredientIndex: Int, isChecked: Boolean) {
        val cocktail = cocktails.find { it.id == cocktailId } ?: return
        val updatedIngredients = cocktail.ingredients.toMutableList()
        updatedIngredients[ingredientIndex] = updatedIngredients[ingredientIndex].copy(isChecked = isChecked)
        val updatedCocktail = cocktail.copy(ingredients = updatedIngredients)
        val index = cocktails.indexOfFirst { it.id == cocktailId }
        if (index != -1) {
            cocktails[index] = updatedCocktail
        }
    }

    fun isAllIngredientsChecked(cocktailId: Int): Boolean {
        val cocktail = cocktails.find { it.id == cocktailId } ?: return false
        return cocktail.ingredients.all { it.isChecked }
    }

    fun resetCocktailChecks(cocktailId: Int) {
        val cocktail = cocktails.find { it.id == cocktailId } ?: return
        val updated = cocktail.copy(ingredients = cocktail.ingredients.map { it.copy(isChecked = false) })
        updateCocktail(updated)
    }
}
