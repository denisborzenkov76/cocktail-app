package com.example.cocktailapp.ui.navigation

sealed class Screen(val route: String) {
    object Main : Screen("main")
    object CocktailDetail : Screen("cocktail_detail/{cocktailId}") {
        fun createRoute(cocktailId: Int) = "cocktail_detail/$cocktailId"
    }
    object CocktailsManagement : Screen("cocktails_management")
    object CocktailEdit : Screen("cocktail_edit/{id}") {
        fun createRoute(id: String) = "cocktail_edit/$id"
    }
}
