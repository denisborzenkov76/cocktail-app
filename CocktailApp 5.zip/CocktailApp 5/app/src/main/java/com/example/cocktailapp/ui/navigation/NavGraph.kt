package com.example.cocktailapp.ui.navigation

import androidx.compose.runtime.Composable
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.cocktailapp.ui.screens.CocktailDetailScreen
import com.example.cocktailapp.ui.screens.CocktailEditScreen
import com.example.cocktailapp.ui.screens.CocktailsManagementScreen
import com.example.cocktailapp.ui.screens.MainScreen
import com.example.cocktailapp.ui.viewmodel.CocktailViewModel

@Composable
fun NavGraph() {
    val navController = rememberNavController()
    val viewModel: CocktailViewModel = viewModel()

    NavHost(
        navController = navController,
        startDestination = Screen.Main.route
    ) {
        composable(Screen.Main.route) {
            MainScreen(
                viewModel = viewModel,
                onCocktailClick = { cocktailId ->
                    navController.navigate(Screen.CocktailDetail.createRoute(cocktailId))
                },
                onManageCocktails = {
                    navController.navigate(Screen.CocktailsManagement.route)
                }
            )
        }

        composable(
            route = Screen.CocktailDetail.route,
            arguments = listOf(
                navArgument("cocktailId") { type = NavType.IntType }
            )
        ) { backStackEntry ->
            val cocktailId = backStackEntry.arguments?.getInt("cocktailId") ?: return@composable
            CocktailDetailScreen(
                cocktailId = cocktailId,
                viewModel = viewModel,
                onBack = {
                    navController.popBackStack()
                }
            )
        }

        composable(Screen.CocktailsManagement.route) {
            CocktailsManagementScreen(
                viewModel = viewModel,
                onBack = {
                    navController.popBackStack()
                },
                onEditCocktail = { cocktail ->
                    if (cocktail == null) {
                        navController.navigate(Screen.CocktailEdit.createRoute("new"))
                    } else {
                        navController.navigate(Screen.CocktailEdit.createRoute(cocktail.id.toString()))
                    }
                }
            )
        }

        composable(
            route = Screen.CocktailEdit.route,
            arguments = listOf(
                navArgument("id") { type = NavType.StringType }
            )
        ) { backStackEntry ->
            val id = backStackEntry.arguments?.getString("id")
            val cocktail = when (id) {
                "new" -> null
                else -> id?.toIntOrNull()?.let { viewModel.getCocktailById(it) }
            }
            CocktailEditScreen(
                cocktail = cocktail,
                viewModel = viewModel,
                onBack = {
                    navController.popBackStack()
                }
            )
        }
    }
}
