package com.example.cocktailapp.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Circle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Done
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import com.example.cocktailapp.data.Cocktail
import com.example.cocktailapp.data.CocktailManager
import com.example.cocktailapp.data.Ingredient
import com.example.cocktailapp.ui.viewmodel.CocktailViewModel

@Composable
fun CocktailEditScreen(
    cocktail: Cocktail?,
    viewModel: CocktailViewModel,
    onBack: () -> Unit
) {
    var name by remember { mutableStateOf(cocktail?.name ?: "") }
    var base by remember { mutableStateOf(cocktail?.base ?: "") }
    var imageEmoji by remember { mutableStateOf(cocktail?.imageEmoji ?: "🍹") }
    var color by remember { mutableStateOf(cocktail?.color ?: 0xFF6200EE) }
    var instructions by remember { mutableStateOf(cocktail?.instructions ?: "") }
    var glass by remember { mutableStateOf(cocktail?.glass ?: "") }
    var garnish by remember { mutableStateOf(cocktail?.garnish ?: "") }
    
    var ingredients by remember {
        mutableStateOf(cocktail?.ingredients?.toMutableList() ?: mutableListOf())
    }
    
    var showBaseDropdown by remember { mutableStateOf(false) }
    var showEmojiPicker by remember { mutableStateOf(false) }
    var showDeleteIngredientDialog by remember { mutableStateOf<Int?>(null) }

    val availableColors = listOf(
        0xFFE53935, 0xFFD81B60, 0xFF8E24AA, 0xFF5E35B1, 0xFF3949AB,
        0xFF1E88E5, 0xFF039BE5, 0xFF00ACC1, 0xFF00897B, 0xFF43A047,
        0xFF7CB342, 0xFFC0CA33, 0xFFFDD835, 0xFFFFB300, 0xFFFF8F00,
        0xFFFB8C00, 0xFFF4511E, 0xFF6D4C41, 0xFF757575, 0xFF546E7A
    )

    val availableEmojis = listOf(
        "🍹", "🍸", "🥃", "🍺", "🍷", "🥂", "🍾", "🧉", "🫗", "🥤",
        "🌿", "🍋", "🍊", "🍎", "🍓", "🫧", "💧", "🥥", "🍒", "🍑"
    )

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(
                        Icons.Default.ArrowBack,
                        contentDescription = "Назад",
                        tint = MaterialTheme.colorScheme.onSurface
                    )
                }
                Text(
                    text = if (cocktail == null) "Новый коктейль" else "Редактирование",
                    style = MaterialTheme.typography.headlineSmall,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        },
        bottomBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Button(
                    onClick = onBack,
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.surface,
                        contentColor = MaterialTheme.colorScheme.onSurface
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Отмена")
                }
                Button(
                    onClick = {
                        if (name.isBlank() || base.isBlank()) return@Button
                        val cocktailData = Cocktail(
                            id = cocktail?.id ?: 0,
                            name = name,
                            base = base,
                            imageEmoji = imageEmoji,
                            color = color,
                            ingredients = ingredients.toList(),
                            instructions = instructions,
                            glass = glass,
                            garnish = garnish
                        )
                        if (cocktail == null) {
                            viewModel.addCocktail(cocktailData)
                        } else {
                            viewModel.updateCocktail(cocktailData)
                        }
                        onBack()
                    },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.Done, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Сохранить")
                }
            }
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(vertical = 8.dp)
        ) {
            // Эмодзи
            item {
                Column {
                    Text(
                        text = "Иконка",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(60.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(color).copy(alpha = 0.15f))
                                .clickable { showEmojiPicker = true },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = imageEmoji, style = androidx.compose.material3.Typography.headlineLarge)
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = "Нажмите для выбора эмодзи",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                        )
                    }
                }
            }

            // Название
            item {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Название коктейля") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true
                )
            }

            // Основа
            item {
                ExposedDropdownMenuBox(
                    expanded = showBaseDropdown,
                    onExpandedChange = { showBaseDropdown = it }
                ) {
                    OutlinedTextField(
                        value = base,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Основа") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor(),
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = showBaseDropdown) },
                        shape = RoundedCornerShape(12.dp)
                    )
                    ExposedDropdownMenu(
                        expanded = showBaseDropdown,
                        onDismissRequest = { showBaseDropdown = false }
                    ) {
                        CocktailManager.availableBases.forEach { baseOption ->
                            DropdownMenuItem(
                                text = { Text(baseOption) },
                                onClick = {
                                    base = baseOption
                                    showBaseDropdown = false
                                }
                            )
                        }
                    }
                }
            }

            // Цвет
            item {
                Column {
                    Text(
                        text = "Цвет карточки",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        availableColors.chunked(7).forEach { rowColors ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                rowColors.forEach { c ->
                                    Box(
                                        modifier = Modifier
                                            .size(36.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(Color(c))
                                            .clickable { color = c },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        if (color == c) {
                                            Icon(
                                                Icons.Default.CheckCircle,
                                                contentDescription = null,
                                                tint = Color.White,
                                                modifier = Modifier.size(20.dp)
                                            )
                                        }
                                    }
                                    Spacer(modifier = Modifier.width(4.dp))
                                }
                            }
                        }
                    }
                }
            }

            // Ингредиенты
            item {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Ингредиенты",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.weight(1f))
                        IconButton(onClick = {
                            ingredients.add(Ingredient("", ""))
                        }) {
                            Icon(Icons.Default.Add, contentDescription = "Добавить", tint = MaterialTheme.colorScheme.primary)
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    ingredients.forEachIndexed { index, ingredient ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(24.dp)
                                    .clip(RoundedCornerShape(100))
                                    .background(Color(color).copy(alpha = 0.15f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = if (ingredient.name.isNotBlank()) Icons.Default.CheckCircle else Icons.Default.Circle,
                                    contentDescription = null,
                                    tint = if (ingredient.name.isNotBlank()) MaterialTheme.colorScheme.primary
                                           else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.3f),
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            OutlinedTextField(
                                value = ingredient.name,
                                onValueChange = { ingredients[index] = ingredient.copy(name = it) },
                                placeholder = { Text("Название") },
                                modifier = Modifier.weight(1f),
                                singleLine = true,
                                shape = RoundedCornerShape(8.dp),
                                colors = androidx.compose.material3.TextFieldDefaults.colors(
                                    focusedContainerColor = MaterialTheme.colorScheme.surface,
                                    unfocusedContainerColor = MaterialTheme.colorScheme.surface
                                )
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            OutlinedTextField(
                                value = ingredient.amount,
                                onValueChange = { ingredients[index] = ingredient.copy(amount = it) },
                                placeholder = { Text("Объём") },
                                modifier = Modifier.weight(1f),
                                singleLine = true,
                                shape = RoundedCornerShape(8.dp),
                                keyboardOptions = KeyboardOptions.Default.copy(imeAction = ImeAction.Next),
                                colors = androidx.compose.material3.TextFieldDefaults.colors(
                                    focusedContainerColor = MaterialTheme.colorScheme.surface,
                                    unfocusedContainerColor = MaterialTheme.colorScheme.surface
                                )
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            IconButton(onClick = { showDeleteIngredientDialog = index }) {
                                Icon(Icons.Default.Delete, contentDescription = "Удалить", tint = MaterialTheme.colorScheme.error)
                            }
                        }
                    }
                }
            }

            // Инструкция
            item {
                OutlinedTextField(
                    value = instructions,
                    onValueChange = { instructions = it },
                    label = { Text("Инструкция по приготовлению") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 4,
                    shape = RoundedCornerShape(12.dp)
                )
            }

            // Стакан
            item {
                OutlinedTextField(
                    value = glass,
                    onValueChange = { glass = it },
                    label = { Text("Тип стакана") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true
                )
            }

            // Украшение
            item {
                OutlinedTextField(
                    value = garnish,
                    onValueChange = { garnish = it },
                    label = { Text("Украшение") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true
                )
            }
        }
    }

    // Диалог выбора эмодзи
    if (showEmojiPicker) {
        AlertDialog(
            onDismissRequest = { showEmojiPicker = false },
            title = { Text("Выберите иконку") },
            text = {
                Column {
                    availableEmojis.chunked(5).forEach { row ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            row.forEach { emoji ->
                                Box(
                                    modifier = Modifier
                                        .size(48.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (imageEmoji == emoji) Color(color).copy(alpha = 0.2f) else MaterialTheme.colorScheme.surface)
                                        .clickable {
                                            imageEmoji = emoji
                                            showEmojiPicker = false
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(text = emoji, style = androidx.compose.material3.Typography.headlineSmall)
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showEmojiPicker = false }) {
                    Text("Готово")
                }
            }
        )
    }

    // Диалог удаления ингредиента
    showDeleteIngredientDialog?.let { index ->
        AlertDialog(
            onDismissRequest = { showDeleteIngredientDialog = null },
            title = { Text("Удалить ингредиент?") },
            text = { Text("Ингредиент \"${ingredients[index].name}\" будет удалён.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        ingredients.removeAt(index)
                        showDeleteIngredientDialog = null
                    },
                    colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Удалить")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteIngredientDialog = null }) {
                    Text("Отмена")
                }
            }
        )
    }
}
