package com.example.cocktailapp.data

object CocktailManager {

    // Начальная база коктейлей
    internal val initialCocktails = listOf(
        Cocktail(
            id = 1,
            name = "Маргарита",
            base = "Теквила",
            imageEmoji = "🍹",
            color = 0xFF4CAF50,
            ingredients = listOf(
                Ingredient("Теквила", "50 мл"),
                Ingredient("Ликёр Контра", "20 мл"),
                Ingredient("Сок лайма", "15 мл"),
                Ingredient("Соль для обрамления", "по вкусу")
            ),
            instructions = "Нанесите соль на край бокала. Наполните шейкер льдом, добавьте теквилу, Контра и сок лайма. Хорошо взбейте. Перелейте в бокал с соленым краем. Украсьте долькой лайма.",
            glass = "Бокал маргариты",
            garnish = "Долька лайма"
        ),
        Cocktail(
            id = 2,
            name = "Джин Тоник",
            base = "Джин",
            imageEmoji = "🫧",
            color = 0xFF8BC34A,
            ingredients = listOf(
                Ingredient("Джин", "50 мл"),
                Ingredient("Тоник", "150 мл"),
                Ingredient("Лимон", "1 долька")
            ),
            instructions = "Наполните бокал льдом. Налейте джин и тоник. Перемешайте барной ложкой. Украсьте долькой лимона.",
            glass = "Бокал хайбол",
            garnish = "Долька лимона"
        ),
        Cocktail(
            id = 3,
            name = "Мохито",
            base = "Ром",
            imageEmoji = "🌿",
            color = 0xFF66BB6A,
            ingredients = listOf(
                Ingredient("Белый ром", "50 мл"),
                Ingredient("Сахарный сироп", "20 мл"),
                Ingredient("Сок лайма", "30 мл"),
                Ingredient("Содовая", "100 мл"),
                Ingredient("Мята", "8 листочков")
            ),
            instructions = "Положите листочки мяты в бокал, добавьте сахарный сироп и слегка подавите. Добавьте сок лайма. Наполните бокал льдом, влейте ром. Долейте содовую. Перемешайте. Украсьте веточкой мяты и долькой лайма.",
            glass = "Хайбол",
            garnish = "Мята и лайм"
        ),
        Cocktail(
            id = 4,
            name = "Водка Сода",
            base = "Водка",
            imageEmoji = "💧",
            color = 0xFF29B6F6,
            ingredients = listOf(
                Ingredient("Водка", "50 мл"),
                Ingredient("Содовая", "150 мл"),
                Ingredient("Лимон", "1 долька")
            ),
            instructions = "Наполните бокал льдом. Налейте водку, долейте содовую. Перемешайте. Украсьте долькой лимона.",
            glass = "Хайбол",
            garnish = "Долька лимона"
        ),
        Cocktail(
            id = 5,
            name = "Олд Фэшн",
            base = "Виски",
            imageEmoji = "🥃",
            color = 0xFF8D6E63,
            ingredients = listOf(
                Ingredient("Бурбон", "60 мл"),
                Ingredient("Ангостура биттерс", "2-3 капли"),
                Ingredient("Сахар", "1 кубик"),
                Ingredient("Вода", "1 ч.л.")
            ),
            instructions = "Положите кубик сахара в роколин, добавьте воду и ангостура биттерс. Растолките до растворения. Добавьте бурбон и большой кубик льда. Аккуратно перемешайте. Украсьте апельсиновой цедой.",
            glass = "Роколин",
            garnish = "Апельсиновая цедра"
        ),
        Cocktail(
            id = 6,
            name = "Пина Колада",
            base = "Ром",
            imageEmoji = "🥥",
            color = 0xFFFFECB3,
            ingredients = listOf(
                Ingredient("Белый ром", "50 мл"),
                Ingredient("Кокосовые сливки", "60 мл"),
                Ingredient("Ананасовый сок", "90 мл"),
                Ingredient("Лёд", "100 г")
            ),
            instructions = "Все ингредиенты поместите в блендер. Взбивайте до получения однородной кремовой массы. Перелейте в бокал гиарини. Украсьте долькой ананаса и вишней.",
            glass = "Гиарини",
            garnish = "Долька ананаса"
        ),
        Cocktail(
            id = 7,
            name = "Негрони",
            base = "Джин",
            imageEmoji = "🔴",
            color = 0xFFE53935,
            ingredients = listOf(
                Ingredient("Джин", "30 мл"),
                Ingredient("Кампари", "30 мл"),
                Ingredient("Сладкий вермут", "30 мл")
            ),
            instructions = "Наполните роколин льдом. Налейте джин, кампари и сладкий вермут. Аккуратно перемешайте. Украсьте долькой апельсина.",
            glass = "Роколин",
            garnish = "Долька апельсина"
        ),
        Cocktail(
            id = 8,
            name = "Дайкири",
            base = "Ром",
            imageEmoji = "🍋",
            color = 0xFFFDD835,
            ingredients = listOf(
                Ingredient("Белый ром", "60 мл"),
                Ingredient("Сок лайма", "30 мл"),
                Ingredient("Сахарный сироп", "15 мл")
            ),
            instructions = "Наполните шейкер льдом, добавьте ром, сок лайма и сахарный сироп. Хорошо взбейте. Процедите в охлаждённый бокал маргариты. Украсьте долькой лайма.",
            glass = "Бокал маргариты",
            garnish = "Долька лайма"
        ),
        Cocktail(
            id = 9,
            name = "Текила Санрайз",
            base = "Теквила",
            imageEmoji = "🌅",
            color = 0xFFFF7043,
            ingredients = listOf(
                Ingredient("Теквила", "50 мл"),
                Ingredient("Апельсиновый сок", "120 мл"),
                Ingredient("Гранатовый сироп", "10 мл"),
                Ingredient("Лимон", "1 долька")
            ),
            instructions = "Наполните хайбол льдом, налейте теквилу и апельсиновый сок. Перемешайте. Аккуратно влейте гранатовый сироп — он создаст градиент. Украсьте долькой лимона.",
            glass = "Хайбол",
            garnish = "Долька лимона"
        ),
        Cocktail(
            id = 10,
            name = "Апероль Шприц",
            base = "Вино",
            imageEmoji = "🧡",
            color = 0xFFFF6E40,
            ingredients = listOf(
                Ingredient("Апероль", "60 мл"),
                Ingredient("Сухое просекко", "90 мл"),
                Ingredient("Содовая", "30 мл"),
                Ingredient("Апельсин", "1 долька")
            ),
            instructions = "Наполните бокал хайбол льдом доверху. Налейте апероль, просекко и содовую. Аккуратно перемешайте. Украсьте долькой апельсина.",
            glass = "Хайбол",
            garnish = "Долька апельсина"
        ),
        Cocktail(
            id = 11,
            name = "Манхэттен",
            base = "Ржаной виски",
            imageEmoji = "🏙️",
            color = 0xFF8E24AA,
            ingredients = listOf(
                Ingredient("Ржаной виски", "60 мл"),
                Ingredient("Сладкий вермут", "30 мл"),
                Ingredient("Ангостура биттерс", "2 капли")
            ),
            instructions = "Наполните смешиваемый стакан льдом, добавьте виски, вермут и биттерс. Перемешайте в течение 30 секунд. Процедите в охлаждённый бокал для мартини. Украсьте вишней марахини.",
            glass = "Бокал для мартини",
            garnish = "Вишня марахини"
        ),
        Cocktail(
            id = 12,
            name = "Клубничное Просекко",
            base = "Водка",
            imageEmoji = "🍾",
            color = 0xFFF0F4C3,
            ingredients = listOf(
                Ingredient("Водка", "30 мл"),
                Ingredient("Просекко", "120 мл"),
                Ingredient("Клубничный сироп", "15 мл"),
                Ingredient("Свежая клубника", "3 штуки")
            ),
            instructions = "Положите клубнику в бокал и подавите. Добавьте водку и клубничный сироп. Аккуратно долейте просекко. Перемешайте. Украсьте целой клубникой.",
            glass = "Флюте",
            garnish = "Свежая клубника"
        ),
        Cocktail(
            id = 13,
            name = "Белый Рус",
            base = "Водка",
            imageEmoji = "🥛",
            color = 0xFFD7CCC8,
            ingredients = listOf(
                Ingredient("Водка", "40 мл"),
                Ingredient("Тёмный ром", "20 мл"),
                Ingredient("Сливки", "30 мл")
            ),
            instructions = "Наполните роколин льдом. Налейте водку, тёмный ром и сливки. Аккуратно перемешайте.",
            glass = "Роколин",
            garnish = "Без украшения"
        ),
        Cocktail(
            id = 14,
            name = "Куба Либре",
            base = "Ром",
            imageEmoji = "🇨🇺",
            color = 0xFF6D4C41,
            ingredients = listOf(
                Ingredient("Светлый ром", "50 мл"),
                Ingredient("Кока-Кола", "120 мл"),
                Ingredient("Сок лайма", "15 мл")
            ),
            instructions = "Наполните хайбол льдом. Налейте ром и сок лайма. Долейте кока-колу. Перемешайте. Украсьте долькой лайма.",
            glass = "Хайбол",
            garnish = "Долька лайма"
        ),
        Cocktail(
            id = 15,
            name = "Гинз Тоник с огурцом",
            base = "Джин",
            imageEmoji = "🥒",
            color = 0xFFA5D6A7,
            ingredients = listOf(
                Ingredient("Джин", "50 мл"),
                Ingredient("Тоник", "150 мл"),
                Ingredient("Огурец", "3 слайса"),
                Ingredient("Лайм", "1 долька")
            ),
            instructions = "Положите слайсы огурца в бокал, слегка подавите. Наполните бокал льдом, налейте джин. Долейте тоник. Перемешайте. Украсьте слайсом огурца и долькой лайма.",
            glass = "Хайбол",
            garnish = "Огурец и лайм"
        ),
        Cocktail(
            id = 16,
            name = "Амарилио",
            base = "Вино",
            imageEmoji = "🍊",
            color = 0xFFEF5350,
            ingredients = listOf(
                Ingredient("Сухое просекко", "90 мл"),
                Ingredient("Апероль", "60 мл")
            ),
            instructions = "Наполните бокал льдом. Налейте апероль, затем просекко. Перемешайте. Украсьте долькой апельсина.",
            glass = "Винный бокал",
            garnish = "Долька апельсина"
        )
    )

    // Доступные основы для сортировки
    val availableBases = listOf("Джин", "Водка", "Ром", "Теквила", "Виски", "Ржаной виски", "Вино")

    // Генерация уникального ID
    private var nextId = initialCocktails.maxOfOrNull { it.id }?.plus(1) ?: 100

    fun generateNextId(): Int {
        return nextId++
    }
}
