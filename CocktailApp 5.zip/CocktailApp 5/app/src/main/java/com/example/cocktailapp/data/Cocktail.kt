package com.example.cocktailapp.data

data class Ingredient(
    val name: String,
    val amount: String,
    val isChecked: Boolean = false
)

data class Cocktail(
    val id: Int,
    val name: String,
    val base: String,
    val imageEmoji: String,
    val color: Long,
    val ingredients: List<Ingredient>,
    val instructions: String,
    val glass: String,
    val garnish: String
)
